package com.lz.entity;

public class Student {
	
	private Integer s_i;
	private Integer e_id;
	private String s_id;
	private String s_name;
	private String s_class;
	private String s_ip;
	private Boolean s_online;
	private String s_fname;
	private String s_fpath;
	private String s_score;
	private String s_comment;
	//构造方法，域
	
	public String getS_fname() {
		return s_fname;
	}
	public void setS_fname(String s_fname) {
		this.s_fname = s_fname;
	}
	public String getS_fpath() {
		return s_fpath;
	}
	public void setS_fpath(String s_fpath) {
		this.s_fpath = s_fpath;
	}
	public String getS_score() {
		return s_score;
	}
	public void setS_score(String s_score) {
		this.s_score = s_score;
	}
	public String getS_comment() {
		return s_comment;
	}
	public void setS_comment(String s_comment) {
		this.s_comment = s_comment;
	}
	public Integer getS_i() {
		return s_i;
	}
	public void setS_i(Integer s_i) {
		this.s_i = s_i;
	}
	public Integer getE_id() {
		return e_id;
	}
	public void setE_id(Integer e_id) {
		this.e_id = e_id;
	}
	public String getS_id() {
		return s_id;
	}
	public void setS_id(String s_id) {
		this.s_id = s_id;
	}
	public String getS_name() {
		return s_name;
	}
	public void setS_name(String s_name) {
		this.s_name = s_name;
	}
	public String getS_class() {
		return s_class;
	}
	public void setS_class(String s_class) {
		this.s_class = s_class;
	}
	public String getS_ip() {
		return s_ip;
	}
	public void setS_ip(String s_ip) {
		this.s_ip = s_ip;
	}
	public Boolean getS_online() {
		return s_online;
	}
	public void setS_online(Boolean s_online) {
		this.s_online = s_online;
	}
}
