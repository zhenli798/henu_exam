package com.lz.entity;

public class myFile {
	private Integer f_id;
	private String s_id;
	private String f_name;
	private String f_path;
	private Integer f_size;
	private String f_time;
	public Integer getF_id() {
		return f_id;
	}
	public void setF_id(Integer f_id) {
		this.f_id = f_id;
	}
	public String getS_id() {
		return s_id;
	}
	public void setS_id(String s_id) {
		this.s_id = s_id;
	}
	public String getF_name() {
		return f_name;
	}
	public void setF_name(String f_name) {
		this.f_name = f_name;
	}
	public String getF_path() {
		return f_path;
	}
	public void setF_path(String f_path) {
		this.f_path = f_path;
	}
	public Integer getF_size() {
		return f_size;
	}
	public void setF_size(Integer f_size) {
		this.f_size = f_size;
	}
	public String getF_time() {
		return f_time;
	}
	public void setF_time(String f_time) {
		this.f_time = f_time;
	}
	
	
	
}
